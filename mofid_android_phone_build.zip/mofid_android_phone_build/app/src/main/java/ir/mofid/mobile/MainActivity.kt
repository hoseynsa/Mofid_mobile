package ir.mofid.mobile

import android.app.Activity
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.widget.*
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Starter UI + independent rate schedulers.
 * Network/order adapter intentionally NOT connected in this starter.
 * A 5ms interval is a target, not a timing guarantee on Android.
 */
class MainActivity : Activity() {
    private val executor = Executors.newScheduledThreadPool(2)
    private val running = AtomicBoolean(false)
    private var probeTask: ScheduledFuture<*>? = null
    private var orderTask: ScheduledFuture<*>? = null
    private lateinit var status: TextView
    private lateinit var probeRate: EditText
    private lateinit var orderRate: EditText
    private var probeTicks = 0L
    private var orderTicks = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        fun label(s: String) = TextView(this).apply {
            text = s; textSize = 17f; setPadding(0, 14, 0, 6)
        }
        layout.addView(label("ربات همراه مفید — نسخه پایه اندروید"))
        layout.addView(label("نرخ هدف Probe (درخواست/ثانیه)"))
        probeRate = EditText(this).apply { setText("200"); inputType = 2 }
        layout.addView(probeRate)
        layout.addView(label("نرخ هدف سفارش اصلی (درخواست/ثانیه)"))
        orderRate = EditText(this).apply { setText("200"); inputType = 2 }
        layout.addView(orderRate)
        status = label("وضعیت: متوقف | ارسال شبکه‌ای غیرفعال")
        layout.addView(status)
        val start = Button(this).apply { text = "شروع زمان‌بندی آزمایشی (بدون ارسال سفارش)" }
        val stop = Button(this).apply { text = "توقف اضطراری" }
        layout.addView(start); layout.addView(stop)
        layout.addView(label("توجه: Probe در نسخه پایتون اصلی POST واقعی به endpoint سفارش می‌زند؛ بنابراین ذاتاً بی‌خطر/فقط‌خواندنی نیست."))
        layout.addView(label("این نسخه فقط زمان‌بندی و شمارنده را آزمایش می‌کند. هیچ درخواست HTTP و هیچ سفارشی ارسال نمی‌شود."))
        setContentView(ScrollView(this).apply { addView(layout) })

        start.setOnClickListener { startSchedulers() }
        stop.setOnClickListener { stopSchedulers() }
    }

    private fun startSchedulers() {
        if (!running.compareAndSet(false, true)) return
        val p = probeRate.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: 200
        val o = orderRate.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: 200
        probeTicks = 0; orderTicks = 0
        // Separate schedules; each interval is 1/rate. This is a local timing test only.
        probeTask = executor.scheduleAtFixedRate({ probeTicks++ }, 0, (1_000_000_000L / p).coerceAtLeast(1), TimeUnit.NANOSECONDS)
        orderTask = executor.scheduleAtFixedRate({ orderTicks++ }, 0, (1_000_000_000L / o).coerceAtLeast(1), TimeUnit.NANOSECONDS)
        status.text = "زمان‌بندی فعال — Probe: $p/s ، سفارش: $o/s\nارسال شبکه‌ای: خاموش"
        status.postDelayed(object : Runnable {
            override fun run() {
                if (!running.get()) return
                status.text = "زمان‌بندی فعال — شمارنده Probe: $probeTicks | سفارش: $orderTicks\nارسال شبکه‌ای: خاموش"
                status.postDelayed(this, 500)
            }
        }, 500)
    }

    private fun stopSchedulers() {
        running.set(false)
        probeTask?.cancel(true); orderTask?.cancel(true)
        probeTask = null; orderTask = null
        status.text = "متوقف شد — ارسال شبکه‌ای: خاموش"
    }

    override fun onDestroy() {
        stopSchedulers()
        executor.shutdownNow()
        super.onDestroy()
    }
}
